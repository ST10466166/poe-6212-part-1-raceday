USE RaceDayDB;
GO

SELECT *
FROM Users;