--CREATE DATABASE RaceDayDB;
--GO
--USE RaceDayDB;
--GO

--CREATE TABLE Users
--(
--    UserID INT IDENTITY(1,1) PRIMARY KEY,

--    FirstName NVARCHAR(50) NOT NULL,

--    LastName NVARCHAR(50) NOT NULL,

--    Email NVARCHAR(100) NOT NULL UNIQUE,

--    PasswordHash NVARCHAR(255) NOT NULL,

--    PhoneNumber NVARCHAR(20) NULL,

--    Role NVARCHAR(20) NOT NULL,

--    CreatedAt DATETIME2 NOT NULL
--        DEFAULT SYSDATETIME(),

--    CONSTRAINT CK_Users_Role
--        CHECK (Role IN ('Organiser', 'Participant'))
--);

--CREATE TABLE UserProfiles
--(
--    ProfileID INT IDENTITY(1,1) PRIMARY KEY,

--    UserID INT NOT NULL UNIQUE,

--    DateOfBirth DATE NULL,

--    Gender NVARCHAR(20) NULL,

--    EmergencyContactName NVARCHAR(100) NULL,SSS

--    EmergencyContactPhone NVARCHAR(20) NULL,

--    Address NVARCHAR(255) NULL,

--    CONSTRAINT FK_UserProfiles_Users
--        FOREIGN KEY (UserID)
--        REFERENCES Users(UserID)
--        ON DELETE CASCADE
--);
--GO


--CREATE TABLE Events
--(
--    EventID INT IDENTITY(1,1) PRIMARY KEY,

--    OrganiserID INT NOT NULL,

--    EventName NVARCHAR(150) NOT NULL,

--    Description NVARCHAR(1000) NULL,

--    EventDate DATE NOT NULL,

--    Location NVARCHAR(255) NOT NULL,

--    DistanceKm DECIMAL(6,2) NOT NULL,

--    EventType NVARCHAR(20) NOT NULL,

--    Status NVARCHAR(20) NOT NULL
--        DEFAULT 'Upcoming',

--    CreatedAt DATETIME2 NOT NULL
--        DEFAULT SYSDATETIME(),

--    CONSTRAINT FK_Events_Organiser
--        FOREIGN KEY (OrganiserID)
--        REFERENCES Users(UserID),

--    CONSTRAINT CK_Events_EventType
--        CHECK (EventType IN ('Run', 'Walk', 'Cycle')),

--    CONSTRAINT CK_Events_Distance
--        CHECK (DistanceKm > 0),

--    CONSTRAINT CK_Events_Status
--        CHECK
--        (
--            Status IN
--            ('Upcoming', 'Open', 'Completed', 'Cancelled')
--        )
--);
--GO


--CREATE TABLE Categories
--(
--    CategoryID INT IDENTITY(1,1) PRIMARY KEY,

--    EventID INT NOT NULL,

--    CategoryName NVARCHAR(100) NOT NULL,

--    CategoryType NVARCHAR(20) NOT NULL,

--    Description NVARCHAR(500) NULL,

--    CONSTRAINT FK_Categories_Event
--        FOREIGN KEY (EventID)
--        REFERENCES Events(EventID)
--        ON DELETE CASCADE,

--    CONSTRAINT CK_Categories_Type
--        CHECK (CategoryType IN ('Age', 'Distance'))
--);
--GO

--CREATE TABLE Enrollments
--(
--    EnrollmentID INT IDENTITY(1,1) PRIMARY KEY,

--    EventID INT NOT NULL,

--    ParticipantID INT NOT NULL,

--    CategoryID INT NOT NULL,

--    EnrollmentDate DATETIME2 NOT NULL
--        DEFAULT SYSDATETIME(),

--    Status NVARCHAR(20) NOT NULL
--        DEFAULT 'Enrolled',

--    CONSTRAINT FK_Enrollments_Event
--        FOREIGN KEY (EventID)
--        REFERENCES Events(EventID)
--        ON DELETE CASCADE,

--    CONSTRAINT FK_Enrollments_Participant
--        FOREIGN KEY (ParticipantID)
--        REFERENCES Users(UserID),

--    CONSTRAINT FK_Enrollments_Category
--        FOREIGN KEY (CategoryID)
--        REFERENCES Categories(CategoryID),

--    CONSTRAINT UQ_Enrollment
--        UNIQUE (EventID, ParticipantID),

--    CONSTRAINT CK_Enrollment_Status
--        CHECK
--        (
--            Status IN
--            ('Enrolled', 'Cancelled', 'Completed')
--        )
--);
--GO

--CREATE TABLE Results
--(
--    ResultID INT IDENTITY(1,1) PRIMARY KEY,

--    EnrollmentID INT NOT NULL UNIQUE,

--    FinishTime TIME NULL,

--    FinishingPosition INT NULL,

--    ResultStatus NVARCHAR(20) NOT NULL
--        DEFAULT 'Finished',

--    RecordedAt DATETIME2 NOT NULL
--        DEFAULT SYSDATETIME(),

--    CONSTRAINT FK_Results_Enrollment
--        FOREIGN KEY (EnrollmentID)
--        REFERENCES Enrollments(EnrollmentID)
--        ON DELETE CASCADE,

--    CONSTRAINT CK_Results_Position
--        CHECK
--        (
--            FinishingPosition IS NULL
--            OR FinishingPosition > 0
--        ),

--    CONSTRAINT CK_Results_Status
--        CHECK
--        (
--            ResultStatus IN
--            ('Finished', 'DidNotFinish', 'Disqualified')
--        )
--);
--GO

